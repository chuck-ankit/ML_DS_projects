# Install and load the 'ineq' package
#install.packages("ineq")
library(ineq)

# Create a hypothetical income dataset
df <- data.frame(income = c(30000, 50000, 70000, 80000, 20000, 100000))

# Calculate Gini coefficient
gini_coefficient <- Gini(df$income)
print(paste("Gini Coefficient:", gini_coefficient))

# Plot Lorenz curve
lorenz_curve <- Lc(df$income)
plot(lorenz_curve, main="Lorenz Curve", xlab="Cumulative share of population", ylab="Cumulative share of income", col="blue", lwd=2)
abline(h = 0.5, v = 0.5, col = "red", lty = 2)
