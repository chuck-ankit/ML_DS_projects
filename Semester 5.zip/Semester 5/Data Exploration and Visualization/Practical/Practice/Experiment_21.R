# Create a data frame with multiple variables
data <- data.frame(
  var1 = c(23, 45, 67, 89, 34),
  var2 = c(560, 430, 670, 890, 340),
  var3 = c(12, 56, 78, 90, 43)
)

# Standardize the variables using the scale() function
scaled_data <- scale(data)

# View the standardized data
print("Original Data:")
print(data)

print("\nStandardized Data:")
print(scaled_data)

# Function to scale variables to a specific range
scale_to_range <- function(x, min_val = 0, max_val = 1) {
  (x - min(x)) / (max(x) - min(x)) * (max_val - min_val) + min_val
}

# Apply the function to each column of the data frame
scaled_range_data <- as.data.frame(lapply(data, scale_to_range))

# View the scaled data to a specific range
print("\nScaled Data to Range [0, 1]:")
print(scaled_range_data)
