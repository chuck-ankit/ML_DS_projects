# Create a sample data frame
df <- data.frame(
  Gender = c("Male", "Female", "Male", "Female", "Male", "Female"),
  Preference = c("A", "B", "B", "A", "A", "B")
)

# Create a contingency table
contingency_table <- table(df$Gender, df$Preference)

# Display the contingency table
print("Contingency Table:")
print(contingency_table)

# Perform chi-squared test
chi_squared_test <- chisq.test(contingency_table)
print("\nChi-squared Test:")
print(chi_squared_test)

# Visual analysis using mosaic plot
library(vcd)
mosaic(contingency_table, shade = TRUE, legend = TRUE, main = "Mosaic Plot")

# Install necessary package (if not installed)
install.packages("vcd")

# Load the package
library(vcd)
