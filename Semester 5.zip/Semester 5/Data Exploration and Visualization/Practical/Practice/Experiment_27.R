# Create sample data
data <- data.frame(
  Variable1 = sample(c("A", "B", "C"), 100, replace = TRUE),
  Variable2 = sample(c("X", "Y", "Z"), 100, replace = TRUE),
  Variable3 = sample(c("M", "N"), 100, replace = TRUE)
)

# Create a three-way contingency table
contingency_table <- ftable(data$Variable1, data$Variable2, data$Variable3)

# Print the table
print(contingency_table)
