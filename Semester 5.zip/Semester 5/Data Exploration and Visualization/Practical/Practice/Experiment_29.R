# Install and load necessary packages
install.packages(c("zoo", "xts"))

# Load required libraries
library(zoo)
library(xts)

# Create sample time series data
set.seed(123)
date_sequence <- seq(as.Date("2022-01-01"), as.Date("2022-01-10"), by = "days")
value <- rnorm(length(date_sequence))

# Create a time series object
ts_data <- zoo(value, order.by = date_sequence)

# Simulate missing values
ts_data[sample(length(ts_data), 3)] <- NA

# Interpolate missing values
ts_data <- na.approx(ts_data)

# Convert to xts object
xts_data <- as.xts(ts_data)

# Print the cleaned and preprocessed data
print(xts_data)
