# Install and load necessary packages
install.packages(c("nlme", "lme4"))
library(nlme)
library(lme4)

# Create sample longitudinal data
set.seed(123)
subject <- rep(1:50, each = 5)
time <- rep(1:5, times = 50)
response <- rnorm(250, mean = 0, sd = 1) + 0.1 * time + rnorm(250, mean = 0, sd = 0.5)

data <- data.frame(subject = factor(subject), time = factor(time), response)

# Fit a linear mixed-effects model (LMM)
lme_model <- lme(response ~ time, random = ~1 | subject, data = data)

# Print the summary of the model
summary(lme_model)
