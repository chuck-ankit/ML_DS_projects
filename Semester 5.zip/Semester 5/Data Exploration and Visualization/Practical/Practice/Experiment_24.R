# Create a sample data frame
df <- data.frame(
  Gender = c("Male", "Female", "Male", "Female", "Male", "Female"),
  Preference = c("A", "B", "B", "A", "A", "B")
)

# Create a contingency table
contingency_table <- table(df$Gender, df$Preference)

# Display the contingency table
print("Contingency Table:")
print(contingency_table)

# Calculate row percentages
row_percentages <- prop.table(contingency_table, margin = 1) * 100

# Calculate column percentages
column_percentages <- prop.table(contingency_table, margin = 2) * 100

# Display row percentages
print("\nRow Percentages:")
print(row_percentages)

# Display column percentages
print("\nColumn Percentages:")
print(column_percentages)
