# Install and load necessary packages
install.packages(c("zoo", "ggplot2"))

# Load required libraries
library(zoo)
library(ggplot2)

# Create sample time series data
set.seed(123)
date_sequence <- seq(as.Date("2022-01-01"), as.Date("2022-01-10"), by = "days")
value <- rnorm(length(date_sequence))

# Create a time series object
ts_data <- zoo(value, order.by = date_sequence)

# Create a time series plot using ggplot2
ggplot(as.data.frame(ts_data), aes(x = index(ts_data), y = coredata(ts_data))) +
  geom_line() +
  labs(title = "Time Series Plot",
       x = "Date",
       y = "Value") +
  theme_minimal()
