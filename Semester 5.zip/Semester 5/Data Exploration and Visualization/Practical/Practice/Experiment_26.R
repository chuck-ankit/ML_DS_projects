# Create a sample data frame
df <- data.frame(
  X = c(1, 2, 3, 4, 5),
  Y = c(3, 6, 8, 10, 12)
)

# Perform linear regression
reg_model <- lm(Y ~ X, data = df)

# Display regression summary
summary(reg_model)

# Plot the data and regression line
plot(df$X, df$Y, main = "Scatter Plot with Regression Line", xlab = "X", ylab = "Y")
abline(reg_model, col = "red")
