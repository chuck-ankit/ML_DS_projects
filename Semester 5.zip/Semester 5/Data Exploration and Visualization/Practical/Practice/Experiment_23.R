# Install and load necessary packages
# install.packages(c("zoo", "ggplot2"))
library(zoo)
library(ggplot2)

# Create a sample data frame
df <- data.frame(
  date = seq(as.Date("2023-01-01"), as.Date("2023-01-10"), by = "days"),
  value = c(30, 45, 60, 80, 40, 100, 120, 90, 70, 50)
)

# Convert your data to a time series object
ts_data <- zoo(df$value, order.by = as.Date(df$date))

# Apply moving average smoothing
ma_smooth <- rollmean(ts_data, k = 3, align = "center", fill = NA)

# Apply LOESS (locally estimated scatterplot smoothing)
loess_smooth <- loess(ts_data ~ as.numeric(time(ts_data)), span = 0.2)

# Predict values based on the LOESS model
loess_smooth_values <- predict(loess_smooth, newdata = as.numeric(time(ts_data)))

# Plot the original and smoothed time series
ggplot() +
  geom_line(aes(x = index(ts_data), y = coredata(ts_data)), color = "blue", linetype = "solid") +
  geom_line(aes(x = index(ts_data), y = ma_smooth), color = "red", linetype = "dashed", size = 1) +
  geom_line(aes(x = index(ts_data), y = loess_smooth_values), color = "green", linetype = "dotted", size = 1) +
  labs(title = "Time Series Smoothing", x = "Date", y = "Value") +
  theme_minimal()
