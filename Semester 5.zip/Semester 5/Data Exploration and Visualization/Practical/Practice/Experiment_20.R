# Install necessary packages (if not installed)
 install.packages("ggplot2")
 install.packages("dplyr")
#Load the packages
 library(ggplot2)
 library(dplyr)
 
 #Measures of Central Tendency:
 
 # Create a numeric vector (you can replace this with your own data)
 data <- c(23, 45, 67, 89, 34, 56, 78, 90, 12, 43)
 
 # Mean
 mean_value <- mean(data)
 print(paste("Mean:", mean_value))
 
 # Median
 median_value <- median(data)
 print(paste("Median:", median_value))
 
 # Mode (using a custom function)
 mode <- function(x) {
   ux <- unique(x)
   ux[which.max(tabulate(match(x, ux)))]
 }
 mode_value <- mode(data)
 print(paste("Mode:", mode_value))
 
#Measures of Variability:
 
 # Standard Deviation
 sd_value <- sd(data)
 print(paste("Standard Deviation:", sd_value))
 
 # Variance
 var_value <- var(data)
 print(paste("Variance:", var_value))
 
 
 # Histogram
 hist(data, main="Histogram", xlab="Values", col="lightblue", border="black")
 
 # Boxplot
 boxplot(data, main="Boxplot", xlab="Values", col="lightgreen", border="black")
 