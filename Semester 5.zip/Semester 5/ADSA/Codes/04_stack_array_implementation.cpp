// Stack implementation using array


//Requirements : - top, *arr, size
//Operations requiered : - push, pop, empty, top , peek



#include<iostream>
using namespace std;

class Stack{
    //Properties
    public:
    int *arr;
    int top ;
    int size ;

    //Behavior
    Stack(int size){
        this-> size = size;
        arr = new int(size);
        top = -1;

    }

    void push(int element){
        if(size-top > 1){
            top++;
            arr[top]=element;
        }
        else{
            cout<<"Stack Overflow"<<endl;
        }
    }

    void pop(){
        if(top >= 0){
            top --;
        }
        else{
            cout<< "StackUnderflow"<<endl;
        }

    }

    bool empty(){
        if(top ==-1){
            return true;
        }
        else{
            return false;
        }
    }

    int peek(){
        if(top >=0){
            return arr[top];
        }
        else{
            cout<<"Stack is empty"<<endl;
            return -1;
        }
    }

    
};


int main(){
    
    Stack bt(5);
    bt.push(1);
    bt.push(2);
    bt.push(3);
    bt.push(4);
    cout<<bt.peek()<<endl;
    bt.pop();
    cout<<bt.peek()<<endl;
    if(bt.empty()){
        cout<<"Stack is Empty."<<endl;
    }
    else{
        cout<<"Stack is not Empty."<<endl;
    }

    return 0;
}