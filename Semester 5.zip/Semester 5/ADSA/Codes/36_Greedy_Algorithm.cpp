//Offline Caching:

#include <iostream>
#include <unordered_set>
#include <vector>

using namespace std;

void offlineCaching(const vector<int>& requests, int cacheSize) {
    unordered_set<int> cache;
    int cacheHits = 0;

    for (int request : requests) {
        if (cache.count(request) > 0) {
            // Cache hit
            cacheHits++;
        } else {
            // Cache miss, replace the least recently used item
            if (cache.size() == cacheSize) {
                auto it = cache.begin();
                cache.erase(it);
            }
            cache.insert(request);
        }
    }

    cout << "Cache Hits: " << cacheHits << endl;
}

int main() {
    vector<int> requests = {1, 2, 3, 4, 1, 2, 5, 1, 2, 3, 4, 5};
    int cacheSize = 3;

    offlineCaching(requests, cacheSize);

    return 0;
}
