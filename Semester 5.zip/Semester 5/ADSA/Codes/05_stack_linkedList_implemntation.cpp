#include<iostream>
using namespace std;

class Node{
public:

    int data;
    Node* link;

    Node(int n){
        this->data = n;
        this->link = NULL;
    }

};

class Stack{
    Node* top ;

public:
    Stack(){
         top = NULL;
    }
    void push(int data){
        Node* temp = new Node(data);
    if(!temp){
        cout<<"\n Stack Overflow";
        exit(1);
    }

    temp->data = data;
    temp->link = top;
    top = temp;
    }
    bool isEmpty(){
        return top==NULL;
    }

    int peek(){
        if(!isEmpty()){
            return top->data;
        }
        else
            exit(1);
    }
    void pop(){
        Node* temp;
        if(top == NULL){
            cout<< " \nStack UnderFlow" << endl;
            exit(1);
        }
        else{
            temp = top;
            top = top->link;
            delete temp;
        }
    }
    void display(){
        cout<<"Our Stack is : ";
        Node*temp;
        if(top==NULL){
            cout<<"\n Stack UnderFlow"<<endl;
            exit(1);
        }
        else{
            temp = top;
            while(top!= NULL){
                cout<<temp->data<<" ";
                temp = temp->link;
                if(temp != NULL){
                    cout<< " -> ";
                }
            }
            cout<<endl;

        }
    }

};


int main(){
    Stack st;
    st.push(11);
    st.push(12);
    st.push(13);
    st.push(14);
    st.display();
    st.pop();
    st.display();
    return 0;
}