//N-Queens Problem:

#include <iostream>
#include <vector>

using namespace std;

bool isSafe(vector<vector<int>>& board, int row, int col, int N) {
    // Check if there is a queen in the same column
    for (int i = 0; i < row; ++i) {
        if (board[i][col] == 1) {
            return false;
        }
    }

    // Check upper left diagonal
    for (int i = row, j = col; i >= 0 && j >= 0; --i, --j) {
        if (board[i][j] == 1) {
            return false;
        }
    }

    // Check upper right diagonal
    for (int i = row, j = col; i >= 0 && j < N; --i, ++j) {
        if (board[i][j] == 1) {
            return false;
        }
    }

    return true;
}

void printBoard(const vector<vector<int>>& board) {
    for (const auto& row : board) {
        for (int cell : row) {
            cout << (cell == 1 ? "Q" : ".") << " ";
        }
        cout << endl;
    }
    cout << endl;
}

bool solveNQueens(vector<vector<int>>& board, int row, int N) {
    if (row == N) {
        // All queens are placed successfully
        printBoard(board);
        return true;
    }

    bool result = false;
    for (int col = 0; col < N; ++col) {
        if (isSafe(board, row, col, N)) {
            board[row][col] = 1; // Place the queen

            // Recur to place the rest of the queens
            result = solveNQueens(board, row + 1, N) || result;

            board[row][col] = 0; // Backtrack
        }
    }

    return result;
}
int main() {
    int N = 4;
    vector<vector<int>> board(N, vector<int>(N, 0));

    if (!solveNQueens(board, 0, N)) {
        cout << "No solution exists." << endl;
    }

    return 0;
}
