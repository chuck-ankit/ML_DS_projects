#include <iostream>

// TreeNode class for the linked list representation of a tree
class TreeNode {
public:
    int value;
    TreeNode* left;
    TreeNode* right;

    TreeNode(int val) : value(val), left(nullptr), right(nullptr) {}
};

// Binary Search Tree class
class BinarySearchTree {
public:
    TreeNode* root;

    BinarySearchTree() : root(nullptr) {}

    // Function to insert a value into the BST
    TreeNode* insert(TreeNode* node, int value) {
        if (node == nullptr) {
            return new TreeNode(value);
        }

        if (value < node->value) {
            node->left = insert(node->left, value);
        } else if (value > node->value) {
            node->right = insert(node->right, value);
        }

        return node;
    }

    // Function to perform in-order traversal
    void inorderTraversal(TreeNode* node) {
        if (node) {
            inorderTraversal(node->left);
            std::cout << node->value << " ";
            inorderTraversal(node->right);
        }
    }

    // Function to perform pre-order traversal
    void preorderTraversal(TreeNode* node) {
        if (node) {
            std::cout << node->value << " ";
            preorderTraversal(node->left);
            preorderTraversal(node->right);
        }
    }

    // Function to perform post-order traversal
    void postorderTraversal(TreeNode* node) {
        if (node) {
            postorderTraversal(node->left);
            postorderTraversal(node->right);
            std::cout << node->value << " ";
        }
    }
};

int main() {
    // Creating a Binary Search Tree
    BinarySearchTree bst;
    bst.root = bst.insert(bst.root, 3);
    bst.insert(bst.root, 1);
    bst.insert(bst.root, 4);
    bst.insert(bst.root, 2);

    // Tree Traversals
    std::cout << "In-order Traversal: ";
    bst.inorderTraversal(bst.root);
    std::cout << std::endl;

    std::cout << "Pre-order Traversal: ";
    bst.preorderTraversal(bst.root);
    std::cout << std::endl;

    std::cout << "Post-order Traversal: ";
    bst.postorderTraversal(bst.root);
    std::cout << std::endl;

    return 0;
}
