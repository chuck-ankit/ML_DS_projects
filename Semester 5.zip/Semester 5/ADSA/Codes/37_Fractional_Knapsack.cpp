#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

struct Item {
    int weight;
    int value;
    double ratio; // Value-to-weight ratio
};

bool compareRatio(const Item& a, const Item& b) {
    return a.ratio > b.ratio;
}

double fractionalKnapsack(vector<Item>& items, int capacity) {
    int n = items.size();
    sort(items.begin(), items.end(), compareRatio);

    double totalValue = 0.0;

    for (int i = 0; i < n; ++i) {
        if (capacity >= items[i].weight) {
            totalValue += items[i].value;
            capacity -= items[i].weight;
        } else {
            // Fractional part
            double fraction = static_cast<double>(capacity) / items[i].weight;
            totalValue += fraction * items[i].value;
            break;
        }
    }

    return totalValue;
}

// Example Usage
int main() {
    vector<Item> items = {{10, 60, 0.0}, {20, 100, 0.0}, {30, 120, 0.0}};
    int capacity = 50;

    double maxValue = fractionalKnapsack(items, capacity);
    cout << "Maximum Value in Fractional Knapsack: " << maxValue << endl;

    return 0;
}
