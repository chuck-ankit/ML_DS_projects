#include <iostream>
#include <vector>
#include <algorithm>

void radixSort(std::vector<int>& arr) {
    int maxNum = *std::max_element(arr.begin(), arr.end());
    int exp = 1;

    while (maxNum / exp > 0) {
        std::vector<std::vector<int>> buckets(10, std::vector<int>());

        for (int num : arr) {
            buckets[(num / exp) % 10].push_back(num);
        }

        arr.clear();
        for (int i = 0; i < 10; ++i) {
            arr.insert(arr.end(), buckets[i].begin(), buckets[i].end());
        }

        exp *= 10;
    }
}

int main() {
    std::vector<int> arr = {170, 45, 75, 90, 802, 24, 2, 66};
    int n = arr.size();

    radixSort(arr);

    std::cout << "Sorted Array: ";
    for (int num : arr) {
        std::cout << num << " ";
    }
    std::cout << std::endl;

    return 0;
}
