#include <iostream>
#include <vector>
#include <algorithm>

using namespace std;

struct Edge {
    int src, dest, weight;
};

bool compareEdges(const Edge& a, const Edge& b) {
    return a.weight < b.weight;
}

int findParent(vector<int>& parent, int i) {
    if (parent[i] == -1)
        return i;
    return findParent(parent, parent[i]);
}

void unionSets(vector<int>& parent, int x, int y) {
    int rootX = findParent(parent, x);
    int rootY = findParent(parent, y);
    parent[rootX] = rootY;
}

int kruskal(vector<Edge>& edges, int V) {
    sort(edges.begin(), edges.end(), compareEdges);

    vector<int> parent(V, -1);
    int totalWeight = 0;
    int edgesInMST = 0;

    for (Edge edge : edges) {
        int rootSrc = findParent(parent, edge.src);
        int rootDest = findParent(parent, edge.dest);

        if (rootSrc != rootDest) {
            unionSets(parent, rootSrc, rootDest);
            totalWeight += edge.weight;
            edgesInMST++;

            if (edgesInMST == V - 1)
                break;
        }
    }

    return totalWeight;
}

// Example Usage
int main() {
    // Example graph represented as a list of edges
    vector<Edge> edges = {
        {0, 1, 2},
        {0, 3, 6},
        {1, 2, 3},
        {1, 4, 5},
        {2, 4, 7},
        {3, 4, 9}
    };

    int V = 5; // Number of vertices
    int totalWeight = kruskal(edges, V);

    cout << "Total Weight of Minimum Spanning Tree: " << totalWeight << endl;

    return 0;
}
