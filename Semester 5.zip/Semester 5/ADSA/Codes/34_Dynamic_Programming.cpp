//Optimal Binary Search Trees  code in c++

#include <iostream>
#include <vector>
#include <limits>

double optimalBinarySearchTree(const std::vector<double>& keys, const std::vector<double>& probabilities) {
    int n = keys.size();
    std::vector<std::vector<double>> dp(n + 1, std::vector<double>(n + 1, 0));

    for (int i = 1; i <= n; ++i) {
        dp[i][i] = probabilities[i - 1];
    }

    for (int len = 2; len <= n; ++len) {
        for (int i = 1; i <= n - len + 1; ++i) {
            int j = i + len - 1;
            dp[i][j] = std::numeric_limits<double>::infinity();

            for (int k = i; k <= j; ++k) {
                dp[i][j] = std::min(dp[i][j], dp[i][k - 1] + dp[k + 1][j] + probabilities[k - 1]);
            }
        }
    }

    return dp[1][n];
}

// Example Usage
int main() {
    std::vector<double> keys = {10, 12, 20};
    std::vector<double> probabilities = {0.34, 0.33, 0.33};

    double cost = optimalBinarySearchTree(keys, probabilities);
    std::cout << "Minimum Cost of Optimal Binary Search Tree: " << cost << std::endl;

    return 0;
}
