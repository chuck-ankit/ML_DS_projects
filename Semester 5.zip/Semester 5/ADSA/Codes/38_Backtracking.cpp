//Sum of Subsets Problem


#include <iostream>
#include <vector>

using namespace std;

void sumOfSubsets(vector<int>& set, int target, vector<int>& currentSubset, int index) {
    if (target == 0) {
        // Print the current subset
        cout << "Subset: ";
        for (int num : currentSubset) {
            cout << num << " ";
        }
        cout << endl;
        return;
    }

    for (int i = index; i < set.size(); ++i) {
        if (target >= set[i]) {
            currentSubset.push_back(set[i]);
            sumOfSubsets(set, target - set[i], currentSubset, i + 1);
            currentSubset.pop_back();
        }
    }
}

int main() {
    vector<int> set = {10, 7, 5, 18, 12, 20, 15};
    int target = 35;
    vector<int> currentSubset;

    cout << "Subsets with sum " << target << ":" << endl;
    sumOfSubsets(set, target, currentSubset, 0);

    return 0;
}
