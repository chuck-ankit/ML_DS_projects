#include<iostream>

using namespace std;

class Queue {
    int* arr;
    int qfront;
    int qrear;
    int size;

public:
    Queue() {
        size = 100001;
        arr = new int[size];
        qfront = 0;
        qrear = 0;
    }

    bool isEmpty() {
        return (qfront == qrear);
    }

    void enqueue(int data) {
        if (qrear == size) {
            cout << "Queue is full." << endl;
        }
        else {
            arr[qrear] = data;
            qrear++;
        }
    }

    int dequeue() {
        if (isEmpty()) {
            cout << "Queue is empty." << endl;
            return -1; // or any other suitable value for an empty queue
        }
        else {
            int ans = arr[qfront];
            arr[qfront] = -1;
            qfront++;
            if (qfront == qrear) {
                qfront = 0;
                qrear = 0;
            }
            return ans;
        }
    }

    int front() {
        if (isEmpty()) {
            cout << "Queue is empty." << endl;
            return -1; // or any other suitable value for an empty queue
        }
        else {
            return arr[qfront];
        }
    }

    int rear() {
        if (isEmpty()) {
            cout << "Queue is empty." << endl;
            return -1; // or any other suitable value for an empty queue
        }
        else {
            return arr[qrear - 1];
        }
    }
};

void printQueue(Queue q) {
    while (!q.isEmpty()) {
        cout << q.dequeue() << " ";
    }
    cout << endl;
}

int main() {
    Queue ab;

    ab.enqueue(12);
    ab.enqueue(13);
    ab.enqueue(14);
    ab.enqueue(15);
    ab.enqueue(16);

    cout << "Size of Queue: " << (ab.rear() - ab.front() + 1) << endl;
    cout << "Front element of the Queue: " << ab.front() << endl;
    cout << "Rear most element of the Queue: " << ab.rear() << endl;

    cout << "Queue elements: ";
    printQueue(ab);

    ab.dequeue();
    cout << "Front element of the Queue: " << ab.front() << endl;
    cout << "Rear most element of the Queue: " << ab.rear() << endl;
    cout << "Queue elements: ";
    printQueue(ab);

    return 0;
}
