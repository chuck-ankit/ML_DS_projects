#include<iostream>

using namespace std;

class Node {
public:
    int data;
    Node* next;

    Node(int value) {
        data = value;
        next = nullptr;
    }
};

class Queue {
private:
    Node* front;
    Node* rear;

public:
    Queue() {
        front = rear = nullptr;
    }

    bool isEmpty() {
        return front == nullptr;
    }

    void enqueue(int data) {
        Node* newNode = new Node(data);
        if (isEmpty()) {
            front = rear = newNode;
        }
        else {
            rear->next = newNode;
            rear = newNode;
        }
    }

    int dequeue() {
        if (isEmpty()) {
            cout << "Queue is empty." << endl;
            return -1; // or any other suitable value for an empty queue
        }
        else {
            int value = front->data;
            Node* temp = front;
            front = front->next;
            delete temp;
            return value;
        }
    }

    int getFront() {
        if (isEmpty()) {
            cout << "Queue is empty." << endl;
            return -1; // or any other suitable value for an empty queue
        }
        else {
            return front->data;
        }
    }

    int getRear() {
        if (isEmpty()) {
            cout << "Queue is empty." << endl;
            return -1; // or any other suitable value for an empty queue
        }
        else {
            return rear->data;
        }
    }

    void display() {
        if (isEmpty()) {
            cout << "Queue is empty." << endl;
            return;
        }

        Node* current = front;
        while (current != nullptr) {
            cout << current->data << " ";
            current = current->next;
        }
        cout << endl;
    }
};

int main() {
    Queue q;

    q.enqueue(12);
    q.enqueue(13);
    q.enqueue(14);
    q.enqueue(15);
    q.enqueue(16);

    cout << "Size of Queue: " << (q.getRear() - q.getFront() + 1) << endl;
    cout << "Front element of the Queue: " << q.getFront() << endl;
    cout << "Rear most element of the Queue: " << q.getRear() << endl;

    cout << "Queue elements: ";
    q.display();

    q.dequeue();
    cout << "Front element of the Queue: " << q.getFront() << endl;
    cout << "Rear most element of the Queue: " << q.getRear() << endl;
    cout << "Queue elements: ";
    q.display();

    return 0;
}
