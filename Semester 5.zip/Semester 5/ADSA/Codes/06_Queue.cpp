//Queue : FIFO Data Structure 
//

#include<iostream>
#include<queue>
#include<stdexcept>

using namespace std;
void printQueue(queue<int> q) {
    while (!q.empty()) {
        cout << q.front() << " ";
        q.pop();
    }
    cout << endl;
}

int main(){
    queue<int> ab;

    ab.push(12);
    ab.push(13);
    ab.push(14);
    ab.push(15);
    ab.push(16);
    // cout<<ab<<endl;
    cout<<"Size of Queue :"<<ab.size()<<endl;
    cout<<"Front element of the Queue "<<ab.front()<<endl;
    cout<<"Rear most element of the Queue "<<ab.back()<<endl;
    cout << "Queue elements: ";
    printQueue(ab);

    ab.pop();
    cout<<"Front element of the Queue "<<ab.front()<<endl;
    cout<<"Rear most element of the Queue "<<ab.back()<<endl;
    cout << "Queue elements: ";
    printQueue(ab);

    return 0;
}