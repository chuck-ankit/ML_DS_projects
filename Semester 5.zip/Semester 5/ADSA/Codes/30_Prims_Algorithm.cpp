#include <iostream>
#include <vector>
#include <queue>
#include <algorithm>

using namespace std;

#define INF 9999999

int prim(vector<vector<int>>& graph, int V) {
    vector<bool> inMST(V, false);
    vector<int> key(V, INF);
    priority_queue<pair<int, int>, vector<pair<int, int>>, greater<pair<int, int>>> pq;

    int src = 0; // Start from vertex 0
    pq.push({0, src});
    key[src] = 0;

    while (!pq.empty()) {
        int u = pq.top().second;
        pq.pop();

        inMST[u] = true;

        for (int v = 0; v < V; ++v) {
            if (graph[u][v] && !inMST[v] && graph[u][v] < key[v]) {
                key[v] = graph[u][v];
                pq.push({key[v], v});
            }
        }
    }

    int totalWeight = 0;
    for (int i = 0; i < V; ++i)
        totalWeight += key[i];

    return totalWeight;
}

// Example Usage
int main() {
    // Example graph represented as an adjacency matrix
    vector<vector<int>> graph = {
        {0, 2, 0, 6, 0},
        {2, 0, 3, 8, 5},
        {0, 3, 0, 0, 7},
        {6, 8, 0, 0, 9},
        {0, 5, 7, 9, 0}
    };

    int V = graph.size();
    int totalWeight = prim(graph, V);

    cout << "Total Weight of Minimum Spanning Tree: " << totalWeight << endl;

    return 0;
}
