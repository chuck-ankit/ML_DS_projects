#include<iostream>
#include<stack>

using namespace std;

int main(){
    //Creating stack
    stack<int> s;

    //Push Operating 
    s.push(10);
    s.push(8);
    s.push(6);
    s.push(4);
    //Pop
    s.pop();
    //Top Elemnt
    cout<< "Printing the top element "<<s.top()<<endl;
    if(s.empty()){
        cout<<"Stack is empty."<<endl;
    }
    else{
        cout<<"Stack is not empty."<<endl;
    }

    cout<<"Size of stack :"<<s.size()<<endl;

}