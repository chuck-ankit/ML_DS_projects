#include <iostream>  // Include the necessary header for 'cout'

using namespace std;

class Node {
public:
    int data;
    Node* next;

    // Constructor
    Node(int data) : data(data), next(nullptr) {}
};

class LinkedList {
private:
    Node* head;

public:
    LinkedList() : head(nullptr) {}

    // Function to insert a new node
    void insert(int value) {
        Node* newNode = new Node(value);
        if (head == nullptr) {
            head = newNode;
        } else {
            Node* temp = head;
            while (temp->next != nullptr) {
                temp = temp->next;
            }
            temp->next = newNode;
        }
        cout << "Inserted " << value << " into the linked list." << endl;
    }

    // Function to delete a node
    void deleteNode(int value) {
        if (head == nullptr) {
            cout << "The list is empty." << endl;
            return;
        }

        Node* temp = head;
        Node* prev = nullptr;

        // If the deleted node is the head
        if (temp != nullptr && temp->data == value) {
            head = temp->next;
            delete temp;
            cout << "Deleted " << value << " from the linked list." << endl;
            return;
        }

        // Search for the node to be deleted
        while (temp != nullptr && temp->data != value) {
            prev = temp;
            temp = temp->next;
        }

        // If the node is not found
        if (temp == nullptr) {
            cout << "Node with value " << value << " not found in the linked list." << endl;
            return;
        }

        // Removing the node
        prev->next = temp->next;
        delete temp;
        cout << "Deleted " << value << " from the linked list." << endl;
    }

    // Function for traversal
    void traverse() {
        cout << "Linked list: ";
        Node* temp = head;
        while (temp != nullptr) {
            cout << temp->data << " ";
            temp = temp->next;
        }
        cout << endl;
    }

    // Destructor to free memory
    ~LinkedList() {
        Node* current = head;
        Node* next;

        while (current != nullptr) {
            next = current->next;
            delete current;
            current = next;
        }
    }
};

int main() {
    LinkedList linkedList;

    linkedList.insert(10);
    linkedList.insert(12);
    linkedList.insert(14);
    linkedList.insert(16);
    linkedList.traverse();
    linkedList.deleteNode(14);
    linkedList.traverse();

    return 0;
}
