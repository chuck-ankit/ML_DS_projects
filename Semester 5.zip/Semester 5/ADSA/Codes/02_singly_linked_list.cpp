#include<iostream>
using namespace std; 

class Node{
    public:
    int data;
    Node* next;

    Node(int data){
        this->data = data;
        this->next = nullptr;
    }
};

class LinkedList{
    public:
        Node* head;
        LinkedList(){
            head = nullptr;
        }

        void append(int value){
            Node* newNode = new Node(value);
            if(!head){
                head = newNode;
                return;
            }

            Node* current = head;
            while (current->next){
                current = current->next;
            }

            current->next = newNode;
        }

        //Function to display liked list
        void display(){
            Node* current=head;
            while (current){
                cout<<current->data<<" ";
                current = current->next ;
            }
            cout<< endl;
        }
};

int main(){
    LinkedList myLis;
    myLis.append(5);
    myLis.append(12);
    myLis.append(22);
    cout<<"Linked List: ";
    myLis.display();

    return 0;
}