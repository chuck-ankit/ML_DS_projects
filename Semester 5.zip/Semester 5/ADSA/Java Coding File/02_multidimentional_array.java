class MultiDimensionArray {
    public static void main(String[] args) {
        // Declaration and initialization of a 2D array
        int[][] multiArray = { { 1, 2, 3 }, { 4, 5, 6 }, { 7, 8, 9 } };

        // Accessing elements and printing them
        System.out.println("Two-Dimensional Array:");
        for (int i = 0; i < multiArray.length; i++) {
            for (int j = 0; j < multiArray[i].length; j++) {
                System.out.print(multiArray[i][j] + " ");
            }
            System.out.println();
        }
    }
}
