import java.util.ArrayList;
import java.util.List;

class StackExample {
    private List<Integer> stack;

    public StackExample() {
        stack = new ArrayList<>();
    }

    public void push(int item) {
        stack.add(item);
    }

    public int pop() {
        if (isEmpty()) {
            throw new IllegalStateException("Stack is empty");
        }
        int lastIndex = stack.size() - 1;
        int poppedItem = stack.get(lastIndex);
        stack.remove(lastIndex);
        return poppedItem;
    }

    public int peek() {
        if (isEmpty()) {
            throw new IllegalStateException("Stack is empty");
        }
        return stack.get(stack.size() - 1);
    }

    public boolean isEmpty() {
        return stack.isEmpty();
    }

    public int size() {
        return stack.size();
    }

    public static void main(String[] args) {
        StackExample myStack = new StackExample();

        myStack.push(5);
        myStack.push(10);
        myStack.push(15);

        System.out.println("Top of the stack: " + myStack.peek());
        System.out.println("Stack size: " + myStack.size());

        while (!myStack.isEmpty()) {
            System.out.println("Popped: " + myStack.pop());
        }
    }
}
