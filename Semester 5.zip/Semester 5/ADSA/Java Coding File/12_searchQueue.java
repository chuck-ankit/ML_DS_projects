import java.util.LinkedList;
import java.util.Queue;

class QueueSearchExample {
    public static boolean searchQueue(Queue<Integer> queue, int target) {
        for (int element : queue) {
            if (element == target) {
                return true; // Element found in the queue
            }
        }
        return false; // Element not found in the queue
    }

    public static void main(String[] args) {
        Queue<Integer> myQueue = new LinkedList<>();

        myQueue.add(10);
        myQueue.add(20);
        myQueue.add(30);

        int targetElement = 20;

        boolean isElementFound = searchQueue(myQueue, targetElement);

        if (isElementFound) {
            System.out.println("Element " + targetElement + " found in the queue.");
        } else {
            System.out.println("Element " + targetElement + " not found in the queue.");
        }
    }
}
