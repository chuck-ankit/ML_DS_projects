class QueueExample {
    private int[] queue;
    private int front, rear, size, capacity;

    public QueueExample(int capacity) {
        this.capacity = capacity;
        this.queue = new int[capacity];
        this.front = this.rear = this.size = 0;
    }

    public void enqueue(int item) {
        if (isFull()) {
            throw new IllegalStateException("Queue is full");
        }
        queue[rear] = item;
        rear = (rear + 1) % capacity;
        size++;
    }

    public int dequeue() {
        if (isEmpty()) {
            throw new IllegalStateException("Queue is empty");
        }
        int item = queue[front];
        front = (front + 1) % capacity;
        size--;
        return item;
    }

    public boolean isFull() {
        return size == capacity;
    }

    public boolean isEmpty() {
        return size == 0;
    }

    public int size() {
        return size;
    }

    public static void main(String[] args) {
        QueueExample myQueue = new QueueExample(5);

        myQueue.enqueue(10);
        myQueue.enqueue(20);
        myQueue.enqueue(30);

        System.out.println("Front of the queue: " + myQueue.dequeue());
        System.out.println("Queue size: " + myQueue.size());

        myQueue.enqueue(40);
        myQueue.enqueue(50);

        while (!myQueue.isEmpty()) {
            System.out.println("Dequeued: " + myQueue.dequeue());
        }
    }
}
