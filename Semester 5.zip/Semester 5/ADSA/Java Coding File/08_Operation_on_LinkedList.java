class Node {
    int data;
    Node next;

    public Node(int data) {
        this.data = data;
        this.next = null;
    }
}

class LinkedListOperations {
    private Node head;

    // Insertion at the end of the linked list
    public void insert(int data) {
        Node newNode = new Node(data);

        if (head == null) {
            head = newNode;
        } else {
            Node current = head;
            while (current.next != null) {
                current = current.next;
            }
            current.next = newNode;
        }
    }

    // Deletion of a node with a specific value
    public void delete(int value) {
        if (head == null) {
            System.out.println("Linked list is empty. Cannot delete.");
            return;
        }

        if (head.data == value) {
            head = head.next;
            return;
        }

        Node current = head;
        Node previous = null;

        while (current != null && current.data != value) {
            previous = current;
            current = current.next;
        }

        if (current == null) {
            System.out.println("Node with value " + value + " not found.");
        } else {
            previous.next = current.next;
        }
    }

    // Traversal and display of the linked list
    public void display() {
        Node current = head;
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }
        System.out.println();
    }

    public static void main(String[] args) {
        LinkedListOperations linkedList = new LinkedListOperations();

        // Inserting elements into the linked list
        linkedList.insert(1);
        linkedList.insert(2);
        linkedList.insert(3);

        // Displaying the linked list
        System.out.print("Linked List: ");
        linkedList.display();

        // Deleting a node with value 2
        linkedList.delete(2);

        // Displaying the linked list after deletion
        System.out.print("Linked List after deletion: ");
        linkedList.display();
    }
}
