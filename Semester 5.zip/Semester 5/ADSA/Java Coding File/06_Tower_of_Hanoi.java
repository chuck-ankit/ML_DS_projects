class TowerOfHanoi {
    public static void solve(int n, char source, char auxiliary, char target) {
        if (n > 0) {
            // Move n-1 disks from source to auxiliary
            solve(n - 1, source, target, auxiliary);

            // Move the nth disk from source to target
            System.out.println("Move disk " + n + " from " + source + " to " + target);

            // Move the n-1 disks from auxiliary to target
            solve(n - 1, auxiliary, source, target);
        }
    }

    public static void main(String[] args) {
        int numberOfDisks = 3;
        solve(numberOfDisks, 'A', 'B', 'C');
    }
}
