class SimpleQueueExample {
    private static final int MAX_SIZE = 5;
    private int[] queue;
    private int front, rear, size;

    public SimpleQueueExample() {
        queue = new int[MAX_SIZE];
        front = rear = size = 0;
    }

    public void enqueue(int item) {
        if (size == MAX_SIZE) {
            System.out.println("Queue is full. Cannot enqueue.");
            return;
        }
        queue[rear] = item;
        rear = (rear + 1) % MAX_SIZE;
        size++;
        System.out.println("Enqueued: " + item);
    }

    public void dequeue() {
        if (size == 0) {
            System.out.println("Queue is empty. Cannot dequeue.");
            return;
        }
        int item = queue[front];
        front = (front + 1) % MAX_SIZE;
        size--;
        System.out.println("Dequeued: " + item);
    }

    public boolean isEmpty() {
        return size == 0;
    }

    public int size() {
        return size;
    }

    public static void main(String[] args) {
        SimpleQueueExample myQueue = new SimpleQueueExample();

        myQueue.enqueue(10);
        myQueue.enqueue(20);
        myQueue.enqueue(30);

        System.out.println("Queue size: " + myQueue.size());

        myQueue.dequeue();
        myQueue.dequeue();
        myQueue.dequeue(); // Trying to dequeue from an empty queue

        System.out.println("Is the queue empty? " + myQueue.isEmpty());
    }
}
