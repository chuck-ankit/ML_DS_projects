class SingleDimensionArray {
    public static void main(String[] args) {
        // Declaration and initialization of a 1D array
        int[] singleArray = { 1, 2, 3, 4, 5 };

        // Accessing elements and printing them
        System.out.print("Single-Dimensional Array: ");
        for (int i = 0; i < singleArray.length; i++) {
            System.out.print(singleArray[i] + " ");
        }
    }
}
